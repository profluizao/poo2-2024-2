package br.com.apirest.vetshop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VetshopApplicationTests {

	@Test
	void contextLoads() {
	}

}
