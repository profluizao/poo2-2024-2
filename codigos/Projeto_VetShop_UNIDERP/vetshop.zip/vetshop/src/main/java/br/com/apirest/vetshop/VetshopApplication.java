package br.com.apirest.vetshop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VetshopApplication {

	public static void main(String[] args) {
		SpringApplication.run(VetshopApplication.class, args);
	}

}
